<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategory extends Model
{
    protected $table = 'clk_1d21ac51df_category';
    protected $primaryKey = 'id_category';
}
