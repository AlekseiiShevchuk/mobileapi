<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductManufacturer extends Model
{
    protected $table = 'clk_1d21ac51df_manufacturer';
}
