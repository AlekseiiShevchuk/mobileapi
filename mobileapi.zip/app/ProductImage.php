<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    protected $primaryKey = 'id_image';
    protected $table = 'clk_1d21ac51df_image';
}
